# CompSysProject1
Computer Systems Project 1

/*How to run code zeroA.c zeroB.c zeroC.C*/

*in command line*  ./a.out(executable file name) test.txt (*input file name*)
for example:
command line:  ./a.out test.txt   //note: input file must be in same file as your current directory

zeroA description:


zeroB description:


zeroC description:

/*How to run 2*/

first compile... gcc 2.c
next run executable file ./a.out processTree.txt

